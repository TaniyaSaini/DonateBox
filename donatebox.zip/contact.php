<?php
define('HOST','sql6.freemysqlhosting.net');
define('USER','sql6132559');
define('PASS','pabI9gYhc9');
define('DB','sql6132559');
 
$con = mysqli_connect(HOST,USER,PASS,DB);

$name=$_REQUEST['un']; 
//$name='tanay';
$sql = "SELECT contact FROM user where username='$name' ";
 
$res = mysqli_query($con,$sql);
 
$result = array();
 
while($row = mysqli_fetch_array($res)){
array_push($result,
array('contact'=>$row[0]
));
}
 
echo json_encode(array("donationitems"=>$result));
 
mysqli_close($con);

 ?>
