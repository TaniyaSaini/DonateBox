<?php
define('HOST','sql6.freemysqlhosting.net');
define('USER','sql6132559');
define('PASS','pabI9gYhc9');
define('DB','sql6132559');
 
$con=mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("db1")or die("cannot select DB");
$sql = "select * from makerequests"; 
$result = mysql_query($sql);
$json = array();
 
if(mysql_num_rows($result)){
while($row=mysql_fetch_assoc($result)){
$json['donationitems'][]=$row;
}
}
mysql_close($con);
echo json_encode($json); 
?> 