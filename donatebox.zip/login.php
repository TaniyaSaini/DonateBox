<?php
define('HOST','sql6.freemysqlhosting.net');
define('USER','sql6132559');
define('PASS','pabI9gYhc9');
define('DB','sql6132559');

 
$con = mysqli_connect(HOST,USER,PASS,DB);

$username = $_POST['username'];
$password = $_POST['password'];
/*
$username='taniya';
$password='123';
*/	
$sql = "select username,password from userlogin where username='$username' and password='$password'";
 
$res = mysqli_query($con,$sql);
 
$result = array();
 
 
$check = mysqli_fetch_array($res);

 
if(isset($check)){

$sql1 = "select admin from user where username='$username'";
$res = mysqli_query($con,$sql1);
$result = array();

while($row = mysqli_fetch_array($res)){
	$row['admin'];
array_push($result,
array('admin'=>$row[0],

));

}
echo json_encode(array("result"=>$result));

echo 'success';
}else{
echo 'failure';
}
 
 
mysqli_close($con);

 ?>
