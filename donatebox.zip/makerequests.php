<?php
define('HOST','sql6.freemysqlhosting.net');
define('USER','sql6132559');
define('PASS','pabI9gYhc9');
define('DB','sql6132559');

 
$con = mysqli_connect(HOST,USER,PASS,DB);


$name=$_POST['name'];
$quantity = $_POST['quantity'];
$specification = $_POST['specification'];
$un=$_POST['un'];


$sql = "insert into makerequests values('$name','$quantity','$specification','$un')"; 

//echo $name,$username,$password,$email,$city,$admin; 
 
$res = mysqli_query($con,$sql);
 
$result = array();
 
 
//$num_rows = mysqli_fetch_array($res);
$num_rows= 'mysqli_num_rows';
 
if($num_rows){
echo 'success';
}else{
echo 'failure';
}
 
 
mysqli_close($con);

 ?>
